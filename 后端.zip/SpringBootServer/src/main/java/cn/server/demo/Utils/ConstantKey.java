package cn.server.demo.Utils;

/**
 * 常量定义
 */
public class ConstantKey {
    public static final String UPLOADPATH = "Coeff_pic"; // 图片存放路径
    public static String basePath;  // 基址路径
    public static final Integer MaxProductRecommend = 4;
    public static final Integer MaxSingleProductRecommend = 1;
    public static final Integer MaxHotProductNum = 4;
}
