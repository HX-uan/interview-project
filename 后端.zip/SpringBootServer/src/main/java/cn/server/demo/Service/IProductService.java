package cn.server.demo.Service;

import cn.server.demo.Entity.Product;
import cn.server.demo.Enums.ResultEnum;
import org.springframework.stereotype.Service;

import java.util.List;


public interface IProductService {

    List<Product> getAllProducts();

    List<Product> getAllProductsByPage(Integer page, Integer rows);

    List<Product> getNProducts(Integer num);

    void updateViewCount(Product product);

    List<Product> getProductsByIds(List<String> list);

    void insertProduct(Product product);
}
