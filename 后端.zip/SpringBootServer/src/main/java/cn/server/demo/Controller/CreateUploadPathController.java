package cn.server.demo.Controller;

import cn.server.demo.Utils.ConstantKey;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.io.File;

/**
 * 自动创建上传目录的方法
 */
@Component
public class CreateUploadPathController implements CommandLineRunner {

    @Value("${web.upload-path}")
    private String basePath;

    @Override
    public void run(String... args) throws Exception {
        File fl = new File(basePath, ConstantKey.UPLOADPATH);
        if (!fl.exists()){
            fl.mkdirs();
        }
        ConstantKey.basePath = basePath;
    }
}
