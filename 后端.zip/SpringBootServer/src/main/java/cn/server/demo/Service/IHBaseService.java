package cn.server.demo.Service;


import cn.server.demo.Entity.Product;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.List;


public interface IHBaseService {

    List<Product> getProductsBySingleItemCfCoeff(List<Product> pidList) throws IOException;

    List<Product> getProductsBySingleProductCoeff(List<Product> pidList) throws IOException;
}
