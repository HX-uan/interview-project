package cn.server.demo.Service;

import cn.server.demo.Enums.ActionType;
import org.springframework.stereotype.Service;


public interface IKafkaService {

    String getLog(String uid, String pid, ActionType type);

    void sendMessage(String message);
}
