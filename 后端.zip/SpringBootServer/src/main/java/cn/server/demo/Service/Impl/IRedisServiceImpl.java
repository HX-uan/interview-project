package cn.server.demo.Service.Impl;

import cn.server.demo.Clients.RedisClient;
import cn.server.demo.Entity.Product;
import cn.server.demo.Service.IProductService;
import cn.server.demo.Service.IRedisService;
import cn.server.demo.Utils.ConstantKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.List;

@Service
public class IRedisServiceImpl implements IRedisService {

    @Autowired
    private RedisClient redisClient;

    @Autowired
    private IProductService productService;

    @Override
    public List<Product> getHotProducts() {
        List<String> list = new ArrayList<>();
        for (int i = 1; i <= ConstantKey.MaxHotProductNum; i++){
            String data = redisClient.getData(String.valueOf(i));
            if (data != null){
                list.add(data);
            }else {
                break;
            }
        }
//        System.out.println(list.toString());
        return productService.getProductsByIds(list);
    }

    @Override
    public void setData(String key, String data) {
        redisClient.setData(key, data);
    }

    @Override
    public void increment(String key) {
        String count = redisClient.getData(key);
        if (count != null){
            Integer viewCount = Integer.valueOf(count) + 1;
            redisClient.setData(key, String.valueOf(viewCount));
        }else {
            redisClient.setData(key, "1");
        }
    }
}
