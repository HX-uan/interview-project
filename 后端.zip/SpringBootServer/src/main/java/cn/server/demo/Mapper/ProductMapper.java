package cn.server.demo.Mapper;

import cn.server.demo.Entity.Product;
import org.apache.ibatis.annotations.Mapper;
import org.apache.ibatis.annotations.Param;

import java.util.List;
import java.util.Map;

@Mapper
public interface ProductMapper {

    List<Product> getAllProducts();

    List<Product> getNProducts(Integer num);

    void updateViewCount(Product product);

    List<Product> getProductsByIds(List<String> map);

    List<Product> getAllProductsByPage(Map<String, Integer> map);

    void insertProduct(Product product);
}
