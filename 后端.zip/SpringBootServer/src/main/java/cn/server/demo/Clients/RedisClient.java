package cn.server.demo.Clients;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.redis.core.RedisTemplate;
import org.springframework.stereotype.Component;

import java.util.ArrayList;
import java.util.List;

@Component
public class RedisClient {

    @Autowired
    private RedisTemplate<String, String> redisTemplate;

    public String getData(String key){
        return redisTemplate.opsForValue().get(key);
    }

    public void setData(String key, String value){
        redisTemplate.opsForValue().set(key, value);
    }

    public List<String> getTopProducts(Integer topN){
        List<String> list = new ArrayList<>();
        for (int i = 1; i <= topN; i++){
            String data = getData(String.valueOf(i));
            if (data != null){
                list.add(data);
            }
        }
        return list;
    }
}