package cn.server.demo.Service.Impl;

import cn.server.demo.Entity.User;
import cn.server.demo.Enums.ResultEnum;
import cn.server.demo.Mapper.UserMapper;
import cn.server.demo.Service.IUserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

@Service
public class IUserServiceImpl implements IUserService {

    @Autowired
    private UserMapper userMapper;

    @Override
    public ResultEnum verifyUser(User user) {
        Long result = userMapper.verifyUser(user);
        if (result != null){
            return ResultEnum.SUCCESS.setData(result);
        }
        return ResultEnum.ERROR;
    }

    @Override
    public User getUserById(String id) {
        User user = userMapper.getUserById(Long.getLong(id));
        if (user != null){
            return user;
        }
        throw new RuntimeException("查无此Id");
    }
}
