package cn.server.demo.Entity;

import java.io.Serializable;

public class User implements Serializable {

    private Long id;
    private String uname;
    private String password;

    public User(Long id, String uname, String password) {
        this.id = id;
        this.uname = uname;
        this.password = password;
    }

    public User(String uname, String password) {
        this.uname = uname;
        this.password = password;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUname() {
        return uname;
    }

    public void setUname(String uname) {
        this.uname = uname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    @Override
    public String toString() {
        return "User{" +
                "id=" + id +
                ", uname='" + uname + '\'' +
                ", password='" + password + '\'' +
                '}';
    }
}
