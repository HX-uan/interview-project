package cn.server.demo.Controller;


import cn.server.demo.Clients.RedisClient;
import cn.server.demo.Entity.Product;
import cn.server.demo.Entity.User;
import cn.server.demo.Enums.ActionType;
import cn.server.demo.Enums.ResultEnum;
import cn.server.demo.Service.*;
import cn.server.demo.Utils.ConstantKey;
import org.json.JSONObject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import java.io.IOException;
import java.util.List;

@Controller
public class IndexController {

    @Autowired
    private IUserService userService;

    @Autowired
    private IProductService productService;

    @Autowired
    private IKafkaService kafkaService;

    @Autowired
    private IRedisService redisService;

    @Autowired
    private IHBaseService ihBaseService;


    private final Integer topSize = ConstantKey.MaxHotProductNum;

    @GetMapping("/scan")
    @ResponseBody
    public ResultEnum scanAction(@RequestParam(value = "uid", defaultValue = "1") String uid, @RequestParam(value = "pid", defaultValue = "1") String pid){
//        System.out.println("uid : " + uid);
//        System.out.println("pid : " + pid);
        redisService.increment(pid);
        String log = kafkaService.getLog(uid, pid, ActionType.Scan);
        kafkaService.sendMessage(log);
        return ResultEnum.SUCCESS;
    }

    @GetMapping("/collect")
    @ResponseBody
    public ResultEnum collectAction(@RequestParam(value = "uid", defaultValue = "1") String uid, @RequestParam(value = "pid", defaultValue = "1") String pid){
        redisService.increment(pid);
        String log = kafkaService.getLog(uid, pid, ActionType.Collect);
        kafkaService.sendMessage(log);
        return ResultEnum.SUCCESS;
    }

    @GetMapping("/buy")
    @ResponseBody
    public ResultEnum buyAction(@RequestParam(value = "uid", defaultValue = "1") String uid, @RequestParam(value = "pid", defaultValue = "1") String pid){
        redisService.increment(pid);
        String log = kafkaService.getLog(uid, pid, ActionType.Buy);
        kafkaService.sendMessage(log);
        return ResultEnum.SUCCESS;
    }

    @ResponseBody
    @GetMapping(value = "/hotProducts", produces = {"text/html;charset=utf-8"})
    public String hotProducts(){
        return new JSONObject(ResultEnum.SUCCESS.setData(getHotProducts())).toString();
    }

    @ResponseBody
    @GetMapping(value = "/allProducts", produces = {"text/html;charset=utf-8"})
    public String allProducts(){
        // 所有商品信息
        List<Product> allProducts = productService.getAllProductsByPage(0, 10);
        return new JSONObject(ResultEnum.SUCCESS.setData(allProducts)).toString();
    }

    @ResponseBody
    @GetMapping(value = "/productsBySingleItemCfCoeff", produces = {"text/html;charset=utf-8"})
    public String productsBySingleItemCfCoeff(){
        List<Product> productsBySingleItemCfCoeff = null;
        try {
            // 推荐商品信息 --- 产品相似度
            productsBySingleItemCfCoeff = ihBaseService.getProductsBySingleItemCfCoeff(getHotProducts());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (productsBySingleItemCfCoeff == null){
            new JSONObject(ResultEnum.DATA_NULL).toString();
        }
        return new JSONObject(ResultEnum.SUCCESS.setData(productsBySingleItemCfCoeff)).toString();
    }

    @ResponseBody
    @GetMapping(value = "/productsBySingleProductCoeff", produces = {"text/html;charset=utf-8"})
    public String productsBySingleProductCoeff(){
        List<Product> productsBySingleProductCoeff = null;
        try {
            // 推荐商品信息 --- 产品相似度
            productsBySingleProductCoeff = ihBaseService.getProductsBySingleProductCoeff(redisService.getHotProducts());
        } catch (IOException e) {
            e.printStackTrace();
        }
        if (productsBySingleProductCoeff == null){
            new JSONObject(ResultEnum.DATA_NULL).toString();
        }
        return new JSONObject(ResultEnum.SUCCESS.setData(productsBySingleProductCoeff)).toString();
    }

    private List<Product> getHotProducts(){
        List<Product> hotProducts = redisService.getHotProducts();
        if (hotProducts.size() != this.topSize){
            List<Product> nProducts = productService.getNProducts(this.topSize - hotProducts.size());
            hotProducts.addAll(nProducts);
        }
        return hotProducts;
    }
}
