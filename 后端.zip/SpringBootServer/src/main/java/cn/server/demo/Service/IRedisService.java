package cn.server.demo.Service;

import cn.server.demo.Entity.Product;
import org.springframework.stereotype.Service;

import java.util.List;

public interface IRedisService {

    List<Product> getHotProducts();

    void setData(String key, String data);

    void increment(String key);
}
