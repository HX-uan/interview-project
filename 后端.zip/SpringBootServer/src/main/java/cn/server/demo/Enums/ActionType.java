package cn.server.demo.Enums;

public enum ActionType {
    Scan(1),
    Collect(2),
    Buy(3);

    private Integer code;

    private ActionType(Integer code){
        this.code = code;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }
}
