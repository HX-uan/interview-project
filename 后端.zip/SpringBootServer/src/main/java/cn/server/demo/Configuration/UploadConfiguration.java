package cn.server.demo.Configuration;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Configuration;
import org.springframework.web.servlet.config.annotation.ResourceHandlerRegistry;
import org.springframework.web.servlet.config.annotation.WebMvcConfigurationSupport;
@Configuration
public class UploadConfiguration extends WebMvcConfigurationSupport {

    /**上传地址*/
    @Value("${file.upload.path}")
    private String filePath;
    /**显示相对地址*/
    @Value("${file.upload.relative}")
    private String fileRelativePath;

    @Override
    protected void addResourceHandlers(ResourceHandlerRegistry registry) {
        registry.addResourceHandler(fileRelativePath)//这个是虚拟路径图片路径
                .addResourceLocations("file:" + filePath);//这个是图片真实路径
//        System.out.println(fileRelativePath);
//        System.out.println("file:" + filePath);
        super.addResourceHandlers(registry);
//        registry.addResourceHandler("/**").addResourceLocations("classpath:/static/");//项目内的图片去static下找
    }
}

