package cn.server.demo.Enums;

public enum ResultEnum {
    ERROR(500, "错误"),
    CHECK_ERROR(501, "格式验证错误"),
    SUCCESS(200, "成功"),
    DATA_NULL(600, "数据为空");

    private Integer code;
    private String msg;
    private Object data;
    private ResultEnum(Integer code, String msg){
        this.code = code;
        this.msg = msg;
    }

    public Object getData() {
        return data;
    }

    public ResultEnum setData(Object data) {
        this.data = data;
        return this;
    }

    public Integer getCode() {
        return code;
    }

    public void setCode(Integer code) {
        this.code = code;
    }

    public String getMsg() {
        return msg;
    }

    public void setMsg(String msg) {
        this.msg = msg;
    }

    @Override
    public String toString() {
        return "ResultEnum{" +
                "code=" + code +
                ", msg='" + msg + '\'' +
                ", data=" + data +
                '}';
    }
}
