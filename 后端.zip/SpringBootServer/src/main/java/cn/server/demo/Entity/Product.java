package cn.server.demo.Entity;

import java.io.Serializable;

public class Product implements Serializable {

    private Long id;
    private String pname;
    private String picUrl;
    private Integer viewCount;

    public Product(Long id, String pname, String picUrl, Integer viewCount) {
        this.id = id;
        this.pname = pname;
        this.picUrl = picUrl;
        this.viewCount = viewCount;
    }

    public Product(Long id, String pname, String picUrl) {
        this.id = id;
        this.pname = pname;
        this.picUrl = picUrl;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getPname() {
        return pname;
    }

    public void setPname(String pname) {
        this.pname = pname;
    }

    public String getPicUrl() {
        return picUrl;
    }

    public void setPicUrl(String picUrl) {
        this.picUrl = picUrl;
    }

    public Integer getViewCount() {
        return viewCount;
    }

    public void setViewCount(Integer viewCount) {
        this.viewCount = viewCount;
    }

    @Override
    public String toString() {
        return "Product{" +
                "id=" + id +
                ", pname='" + pname + '\'' +
                ", picUrl='" + picUrl + '\'' +
                ", viewCount=" + viewCount +
                '}';
    }
}
