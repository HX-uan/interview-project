package cn.server.demo.Mapper;

import cn.server.demo.Entity.User;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface UserMapper {

    Long verifyUser(User user);

    User getUserById(Long id);
}
