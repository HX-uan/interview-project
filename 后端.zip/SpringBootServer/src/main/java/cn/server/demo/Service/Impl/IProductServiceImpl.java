package cn.server.demo.Service.Impl;

import cn.server.demo.Clients.RedisClient;
import cn.server.demo.Entity.Product;
import cn.server.demo.Enums.ResultEnum;
import cn.server.demo.Mapper.ProductMapper;
import cn.server.demo.Service.IProductService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Service
public class IProductServiceImpl implements IProductService {

    @Autowired
    private ProductMapper productMapper;

    @Autowired
    private RedisClient redisClient;

    @Override
    public List<Product> getAllProducts() {
        List<Product> allProducts = productMapper.getAllProducts();
        return getViewCount(allProducts);
    }

    @Override
    public List<Product> getAllProductsByPage(Integer page, Integer rows) {
        Map<String, Integer> map = new HashMap<>();
        map.put("page", page);
        map.put("rows", rows);
        return getViewCount(productMapper.getAllProductsByPage(map));
    }

    @Override
    public List<Product> getNProducts(Integer num) {
        List<Product> allProducts = productMapper.getNProducts(num);
        return getViewCount(allProducts);
    }

    @Override
    public void updateViewCount(Product product) {
        productMapper.updateViewCount(product);
    }

    @Override
    public List<Product> getProductsByIds(List<String> list) {
        if (list.isEmpty()){
            return new ArrayList<>();
        }
        return getViewCount(productMapper.getProductsByIds(list));
    }

    @Override
    public void insertProduct(Product product) {
        productMapper.insertProduct(product);
    }

    public List<Product> getViewCount(List<Product> list){
        for (int i = 0; i < list.size(); i++){
            String id = list.get(i).getId().toString();
            String count = redisClient.getData(id);
            if (count != null){
                list.get(i).setViewCount(Integer.valueOf(count));
            }
        }
        return list;
    }
}
