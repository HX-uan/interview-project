package cn.server.demo.Service.Impl;

import cn.server.demo.Enums.ActionType;
import cn.server.demo.Service.IKafkaService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.kafka.core.KafkaTemplate;
import org.springframework.stereotype.Service;

@Service
public class IKafkaServiceImpl implements IKafkaService {

    private final String topic = "con";

    @Autowired
    private KafkaTemplate<String, String> kafkaTemplate;

    @Override
    public String getLog(String uid, String pid, ActionType type) {
        String log = uid + ";" + pid + ";" + type.getCode().toString() + ";" + getTMS();
        return log;
    }

    private String getTMS(){
        return String.valueOf(System.currentTimeMillis());
    }

    @Override
    public void sendMessage(String message) {
        kafkaTemplate.send(this.topic, message);
    }
}
