package cn.server.demo.Service;

import cn.server.demo.Entity.User;
import cn.server.demo.Enums.ResultEnum;
import org.springframework.stereotype.Service;


public interface IUserService {

    ResultEnum verifyUser(User user);

    User getUserById(String id);
}
