package cn.server.demo.Service.Impl;

import cn.server.demo.Clients.HBaseClient;
import cn.server.demo.Entity.Product;
import cn.server.demo.Service.IHBaseService;
import cn.server.demo.Service.IProductService;
import cn.server.demo.Utils.ConstantKey;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;
import java.util.Map;

@Service
public class IHBaseServiceImpl implements IHBaseService {

    @Autowired
    private IProductService productService;

    @Override
    public List<Product> getProductsBySingleItemCfCoeff(List<Product> pidList) throws IOException {
        List<String> pids = new ArrayList<>();
        for (int i = 0; i < ConstantKey.MaxProductRecommend; i++){
            if (pidList.size() == i){
                break;
            }
            List<Map.Entry> cf = HBaseClient.getRow("cf", pidList.get(i).getId().toString());
            if (cf.isEmpty()) continue;
            cf.sort(new Comparator<Map.Entry>() {
                @Override
                public int compare(Map.Entry o1, Map.Entry o2) {
                    return ((Double) o1.getValue()).compareTo((Double) o2.getValue());
                }
            });
            int max = cf.size() > ConstantKey.MaxSingleProductRecommend ? ConstantKey.MaxSingleProductRecommend : cf.size();
            for (int j = 0; j < max; j++){
                pids.add(String.valueOf(cf.get(cf.size() - 1 - j).getKey()));
            }
            if (pids.size() == ConstantKey.MaxProductRecommend){
                break;
            }
        }
        List<Product> productsByIds = productService.getProductsByIds(pids);
        return productsByIds;
    }

    @Override
    public List<Product> getProductsBySingleProductCoeff(List<Product> pidList) throws IOException {
        List<String> pids = new ArrayList<>();
        for (int i = 0; i < ConstantKey.MaxProductRecommend; i++){
            if (pidList.size() == i){
                break;
            }
            List<Map.Entry> pp = HBaseClient.getRow("pp", pidList.get(i).getId().toString());
            if (pp.isEmpty()) continue;
            pp.sort(new Comparator<Map.Entry>() {
                @Override
                public int compare(Map.Entry o1, Map.Entry o2) {
                    return ((Double) o1.getValue()).compareTo((Double) o2.getValue());
                }
            });
            int max = pp.size() > ConstantKey.MaxSingleProductRecommend ? ConstantKey.MaxSingleProductRecommend : pp.size();
            for (int j = 0; j < max; j++){
                pids.add(String.valueOf(pp.get(pp.size() - 1 - j).getKey()));
            }
            if (pids.size() == ConstantKey.MaxProductRecommend){
                break;
            }
        }
        List<Product> productsByIds = productService.getProductsByIds(pids);
        return productsByIds;
    }
}
