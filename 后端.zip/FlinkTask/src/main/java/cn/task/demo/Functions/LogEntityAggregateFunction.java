package cn.task.demo.Functions;

import cn.task.demo.Entity.LogEntity;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;


public class LogEntityAggregateFunction implements AggregateFunction<LogEntity, Tuple3<String, Integer, Integer>, Tuple3<String, Integer, Integer>> {

    @Override
    public Tuple3<String, Integer, Integer> createAccumulator() {
        return Tuple3.of("", 0, 0);
    }

    @Override
    public Tuple3<String, Integer, Integer> add(LogEntity value, Tuple3<String, Integer, Integer> accumulator) {
        return Tuple3.of(value.getPid(), value.getAction() + accumulator.f1, 0);
    }

    @Override
    public Tuple3<String, Integer, Integer> getResult(Tuple3<String, Integer, Integer> accumulator) {
        return accumulator;
    }

    @Override
    public Tuple3<String, Integer, Integer> merge(Tuple3<String, Integer, Integer> a, Tuple3<String, Integer, Integer> b) {
        return Tuple3.of(a.f0, a.f1 + b.f1, 0);
    }
}
