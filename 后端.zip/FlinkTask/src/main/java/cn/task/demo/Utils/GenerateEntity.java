package cn.task.demo.Utils;

import cn.task.demo.Clients.HBaseClient;
import cn.task.demo.Entity.PortraitEntity;
import cn.task.demo.Entity.ProductEntity;
import cn.task.demo.Entity.UserEntity;
import cn.task.demo.Enums.*;

import java.io.IOException;

public class GenerateEntity {

    public static PortraitEntity getPortraitEntityById(String id, EntityType type) throws IOException {

        PortraitEntity portraitEntity = null;

        switch (type){
            case Product:
                portraitEntity = new ProductEntity();

                portraitEntity.addSex(Sex.convert(HBaseClient.getData("product",id, "sex", Sex.Man.getCode())));
                portraitEntity.addSex(Sex.convert(HBaseClient.getData("product",id, "sex", Sex.Woman.getCode())));

                portraitEntity.addAge(Age.convert(HBaseClient.getData("product",id, "age", Age.Young.getCode())));
                portraitEntity.addAge(Age.convert(HBaseClient.getData("product",id, "age", Age.MiddleYoung.getCode())));
                portraitEntity.addAge(Age.convert(HBaseClient.getData("product",id, "age", Age.Middle.getCode())));

                portraitEntity.addColor(Color.convert(HBaseClient.getData("product",id, "color", Color.Red.getCode())));
                portraitEntity.addColor(Color.convert(HBaseClient.getData("product",id, "color", Color.Green.getCode())));
                portraitEntity.addColor(Color.convert(HBaseClient.getData("product",id, "color", Color.White.getCode())));

                portraitEntity.addCountry(Country.convert(HBaseClient.getData("product",id, "country", Country.China.getCode())));
                portraitEntity.addCountry(Country.convert(HBaseClient.getData("product",id, "country", Country.Germany.getCode())));
                portraitEntity.addCountry(Country.convert(HBaseClient.getData("product",id, "country", Country.USA.getCode())));
                break;
            case User:
                portraitEntity = new UserEntity();

                portraitEntity.addSex(Sex.convert(HBaseClient.getData("user",id, "sex", Sex.Man.getCode())));
                portraitEntity.addSex(Sex.convert(HBaseClient.getData("user",id, "sex", Sex.Woman.getCode())));

                portraitEntity.addAge(Age.convert(HBaseClient.getData("user",id, "age", Age.Young.getCode())));
                portraitEntity.addAge(Age.convert(HBaseClient.getData("user",id, "age", Age.MiddleYoung.getCode())));
                portraitEntity.addAge(Age.convert(HBaseClient.getData("user",id, "age", Age.Middle.getCode())));

                portraitEntity.addColor(Color.convert(HBaseClient.getData("user",id, "color", Color.Red.getCode())));
                portraitEntity.addColor(Color.convert(HBaseClient.getData("user",id, "color", Color.Green.getCode())));
                portraitEntity.addColor(Color.convert(HBaseClient.getData("user",id, "color", Color.White.getCode())));

                portraitEntity.addCountry(Country.convert(HBaseClient.getData("user",id, "country", Country.China.getCode())));
                portraitEntity.addCountry(Country.convert(HBaseClient.getData("user",id, "country", Country.Germany.getCode())));
                portraitEntity.addCountry(Country.convert(HBaseClient.getData("user",id, "country", Country.USA.getCode())));
                break;
        }


        return portraitEntity;
    }
}
