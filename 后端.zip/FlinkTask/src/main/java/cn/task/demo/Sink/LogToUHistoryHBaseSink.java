package cn.task.demo.Sink;

import cn.task.demo.Clients.HBaseClient;
import cn.task.demo.Entity.LogEntity;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;

public class LogToUHistoryHBaseSink extends RichSinkFunction<LogEntity> {

    // 初始化方法
    public void open(Configuration parameters) throws Exception {

    }
    //Writes the given value to the sink. This function is called for every record.
    //每一个元素的插入，都会被调用一次invoke方法
    public void invoke(LogEntity value, Context context) throws Exception {
        System.out.println("u_history : " + value.toString());
        HBaseClient.incrementColumn("u_history", value.getUid(), "pid", value.getPid());
    }

    public void close() throws Exception {

    }

}
