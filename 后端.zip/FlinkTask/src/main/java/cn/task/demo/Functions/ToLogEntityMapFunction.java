package cn.task.demo.Functions;

import cn.task.demo.Entity.LogEntity;
import org.apache.flink.api.common.functions.MapFunction;

public class ToLogEntityMapFunction implements MapFunction<String, LogEntity> {
    @Override
    public LogEntity map(String value) {
        String[] split = value.split(";");
        if (split.length != 4){
            throw new RuntimeException();
        }
        LogEntity logEntity = new LogEntity(split[0], split[1], Integer.valueOf(split[2]), split[3]);
        System.out.println(logEntity);
        System.out.println(logEntity.getTms());
        return logEntity;
    }

}
