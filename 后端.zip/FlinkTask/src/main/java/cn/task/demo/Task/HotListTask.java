package cn.task.demo.Task;

import cn.task.demo.Functions.HotProductWindowFunction;
import cn.task.demo.Functions.LogEntityAggregateFunction;
import cn.task.demo.Functions.ToLogEntityMapFunction;
import cn.task.demo.Mapper.HotProductToRedisMapper;
import org.apache.flink.api.common.functions.ReduceFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;
import org.apache.flink.streaming.connectors.redis.RedisSink;
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisPoolConfig;
import org.apache.flink.util.Collector;

import java.util.Properties;

public class HotListTask {
    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");

        //定义redis服务器信息
        FlinkJedisPoolConfig conf = new FlinkJedisPoolConfig.Builder()
                .setHost("127.0.0.1")
                .setPort(6379).build();

        DataStream<String> stream = env.addSource(new FlinkKafkaConsumer<String>(
                "con", new SimpleStringSchema(), properties));
        stream.map(new ToLogEntityMapFunction())
                .keyBy("pid")
                .timeWindow(Time.seconds(7))
                .aggregate(new LogEntityAggregateFunction())
                .keyBy("2")
                .timeWindow(Time.seconds(1))
                .apply(new HotProductWindowFunction())
                .addSink(new RedisSink<>(conf,new HotProductToRedisMapper()));

        env.execute("HotListTask");
    }
}
