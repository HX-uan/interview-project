package cn.task.demo.Entity;



public class LogEntity {

    private Integer rank;

    private String uid;

    private String pid;

    private Integer action;

    private String tms;

    public LogEntity(String uid, String pid, Integer action, String tms) {
        this.uid = uid;
        this.pid = pid;
        this.action = action;
        this.tms = tms;
        this.rank = 0;
    }

    public LogEntity(){}

    public String getTms() {
        return tms;
    }

    public void setTms(String tms) {
        this.tms = tms;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getPid() {
        return pid;
    }

    public void setPid(String pid) {
        this.pid = pid;
    }

    public Integer getAction() {
        return action;
    }

    public void setAction(Integer action) {
        this.action = action;
    }

    public Integer getRank() {
        return rank;
    }

    public void setRank(Integer rank) {
        this.rank = rank;
    }

    @Override
    public String toString() {
        return this.uid + ";" + this.pid + ";" + this.action;
    }
}
