package cn.task.demo.Enums;

public enum Sex {

    Man("man"),
    Woman("woman"),
    None("none");

    private String code;

    private Sex(String code){
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static Sex convert(String str){
        if (str == null){
            return None;
        }else if (str.equals("man")){
            return Man;
        }else if (str.equals("woman")){
            return Woman;
        }
        return None;
    }
    public static Sex convert(String str, Sex sex){
        if (str == null){
            return None;
        }else if (str.equals("1")){
            return sex;
        }
        return None;
    }
}
