package cn.task.demo.Mapper;

import cn.task.demo.Entity.LogEntity;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommand;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommandDescription;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisMapper;

public class LogToRedisMapper implements RedisMapper<LogEntity> {
    @Override
    public RedisCommandDescription getCommandDescription() {
        return new RedisCommandDescription(RedisCommand.SET, null);
    }

    @Override
    public String getKeyFromData(LogEntity data) {
        return data.getRank().toString();
    }

    @Override
    public String getValueFromData(LogEntity data) {
        return data.getPid();
    }
}
