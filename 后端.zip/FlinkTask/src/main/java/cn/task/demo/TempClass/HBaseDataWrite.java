package cn.task.demo.TempClass;

import cn.task.demo.Clients.HBaseClient;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class HBaseDataWrite {
    public static void main(String[] args) throws Exception {
        String filepath_products = "D:\\Java Projects\\FlinkTask\\src\\main\\java\\cn\\task\\demo\\Clients\\product.txt";
        String filepath_ids = "D:\\Java Projects\\FlinkTask\\src\\main\\java\\cn\\task\\demo\\Clients\\ids.txt";
        List<String> products =  getTxt(filepath_products);
        List<String> ids =  getTxt(filepath_ids);
        Map<String, String> idsMap = new HashMap<>();
        for (String id : ids){
            String[] split = id.split(",");
            idsMap.put(split[0], split[1]);
        }
        Map<String, Map<String, String>> productsMap = new HashMap<>();
        for (String line : products){
            String[] split = line.split(",");
            Map<String, String> map = new HashMap<>();
            map.put("age", split[1]);
            map.put("color", split[2]);
            map.put("country", split[3]);
            map.put("sex", split[4]);
            productsMap.put(split[0], map);
//            String str = "Name : " + split[0] + " \n"
//                    + "\tAge : " + split[1] + " \n"
//                    + "\tColor : " + split[2] + " \n"
//                    + "\tCountry : " + split[3] + " \n"
//                    + "\tSex : " + split[4] + " \n";
//            System.out.println(str);
//            System.out.println("--------------------------------------------");
        }
        for (String id : idsMap.keySet()){
//            System.out.println(idsMap.get(id));
//            System.out.println(productsMap.get(idsMap.get(id)));
            String name = idsMap.get(id);
            Map<String, String> stringStringMap = productsMap.get(name);
            String a = stringStringMap.get("age");
            String age = productsMap.get(idsMap.get(id)).get("age");
                String color = productsMap.get(idsMap.get(id)).get("color");
                String country = productsMap.get(idsMap.get(id)).get("country");
                String sex = productsMap.get(idsMap.get(id)).get("sex");
//               age------------------------------
                if (age.contains(";")){
                    for (String str : age.split(";")){
                        System.out.println("table : product " + id + " age " + str + " 1");
                        HBaseClient.putData("product", id, "age", str, str);
                    }
                }else {
                    if (age.equals("none")){
//                        HBaseClient.putData("product", id, "age", age, "0");
                    }else {
                        System.out.println("table : product " + id + " age " + age + " 1");
                        HBaseClient.putData("product", id, "age", age, age);
                    }
                }
//                color------------------------------
                if (color.contains(";")){
                    for (String str : color.split(";")){
                        System.out.println("table : product " + id + " color " + str + " 1");
                        HBaseClient.putData("product", id, "color", str, str);
                    }
                }else {
                    if (color.equals("none")){
    //                    HBaseClient.putData("product", id, "color", color, "0");
                    }else {
                        System.out.println("table : product " + id + " color " + color + " 1");
                        HBaseClient.putData("product", id, "color", color, color);
                    }
                }
//                country------------------------------
                if (country.contains(";")){
                    for (String str : country.split(";")){
                        System.out.println("table : product " + id + " country " + str + " 1");
                        HBaseClient.putData("product", id, "country", str, str);
                    }
                }else {
                    if (country.equals("none")){
    //                    HBaseClient.putData("product", id, "country", country, "0");
                    }else {
                        System.out.println("table : product " + id + " country " + country + " 1");
                        HBaseClient.putData("product", id, "country", country, country);
                    }
                }
//                sex------------------------------
                if (sex.contains(";")){
                    for (String str : sex.split(";")){
                        System.out.println("table : product " + id + " sex " + str + " 1");
                        HBaseClient.putData("product", id, "sex", str, str);
                    }
                }else {
                    if (sex.equals("none")){
    //                    HBaseClient.putData("product", id, "sex", sex, "0");
                    }else {
                        System.out.println("table : product " + id + " sex " + sex + " 1");
                        HBaseClient.putData("product", id, "sex", sex, sex);
                    }
                }
        }
    }
    /**
     * 读取本地普通文件，将其转化为一个字符串数组
     * @return
     */
    public static List<String> getTxt(String filepath){
        try{
            String temp = null;
            File f = new File(filepath);
            String adn="";
            //指定读取编码用于读取中文
            InputStreamReader read = new InputStreamReader(new FileInputStream(f),"UTF-8");
            List<String> readList = new ArrayList<String>();
            BufferedReader reader=new BufferedReader(read);
            while((temp=reader.readLine())!=null &&!"".equals(temp)){
                readList.add(temp);
            }
            read.close();
            return readList;
        }catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }
}
