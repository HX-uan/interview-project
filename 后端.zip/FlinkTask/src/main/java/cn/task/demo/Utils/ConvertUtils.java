package cn.task.demo.Utils;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class ConvertUtils {

    public static Map<String, Double> listToMap(List<Map.Entry> list){
        Map<String, Double> map = new HashMap<>();
        for (Map.Entry entry : list){
            map.put(String.valueOf(entry.getKey()), (Double)entry.getValue());
        }
        return map;
    }
}
