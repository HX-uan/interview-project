package cn.task.demo.Functions;

import org.apache.flink.api.common.state.ListState;
import org.apache.flink.api.common.state.ListStateDescriptor;
import org.apache.flink.api.common.typeinfo.TypeHint;
import org.apache.flink.api.common.typeinfo.TypeInformation;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class TopNHotItemsFunction  extends KeyedProcessFunction<Tuple, Tuple3<String, Long, Long>, List<Tuple2<String, Integer>>> {

    private final int topSize;

    public TopNHotItemsFunction(int topSize) {
        this.topSize = topSize;
    }

    private ListState<Tuple3<String, Long, Long>> itemState;

    @Override
    public void open(Configuration parameters) throws Exception {
        super.open(parameters);
        // 状态的注册
        ListStateDescriptor<Tuple3<String, Long, Long>> itemsStateDesc = new ListStateDescriptor<Tuple3<String, Long, Long>>(
                "itemState-state",
                TypeInformation.of(new TypeHint<Tuple3<String, Long, Long>>() {})
        );
        itemState = getRuntimeContext().getListState(itemsStateDesc);
    }

    @Override
    public void processElement(Tuple3<String, Long, Long> value, Context context, Collector<List<Tuple2<String, Integer>>> collector) throws Exception {
        itemState.add(value);
        System.out.println("process : " + value.toString());
        // 注册 windowEnd+1 的 EventTime Timer, 当触发时，说明收齐了属于windowEnd窗口的所有商品数据
        System.out.println("timer : " + String.valueOf(value.f2 + 1));
        context.timerService().registerEventTimeTimer(context.timerService().currentProcessingTime() + 5000);
    }


    @Override
    public void onTimer(long timestamp, OnTimerContext ctx, Collector<List<Tuple2<String, Integer>>> out) throws Exception {
        List<Tuple3<String, Long, Long>> allItems = new ArrayList<>();
        for (Tuple3<String, Long, Long> item : itemState.get()) {
            allItems.add(item);
        }
        System.out.println(timestamp);
        System.out.println("onTimer");
        // 提前清除状态中的数据，释放空间
        itemState.clear();
        // 按照点击量从大到小排序
        allItems.sort(new Comparator<Tuple3<String, Long, Long>>() {
            @Override
            public int compare(Tuple3<String, Long, Long> o1, Tuple3<String, Long, Long> o2) {
                return (int) (o2.f1 - o1.f1);
            }
        });
        List<Tuple2<String, Integer>> ret = new ArrayList<>();
        Integer length = allItems.size() > 10 ? 10 : allItems.size();
        for (int i = 1; i <= length; i++){
            ret.add(Tuple2.of(allItems.get(i-1).f0, i-1));
        }
        out.collect(ret);
    }
}
