package cn.task.demo.TempClass;

import cn.task.demo.Clients.HBaseClient;

public class historyWrite {
    public static void main(String[] args) throws Exception {
        for (int i = 1; i < 51; i++){
            System.out.println("table : p_history " + String.valueOf(i) + " uid " + "1" + " 1");
            HBaseClient.putData("p_history", String.valueOf(i), "uid", "1", "1");
        }
        System.out.println("------------------------------");
        for (int i = 1; i < 11; i++){
            System.out.println("table : u_history " + String.valueOf(i) + " pid " + "1" + " 1");
            HBaseClient.putData("u_history", String.valueOf(i), "pid", "1", "1");
        }
    }
}
