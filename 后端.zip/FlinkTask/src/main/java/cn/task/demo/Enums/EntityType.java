package cn.task.demo.Enums;

public enum EntityType {
    Product,
    User;
}
