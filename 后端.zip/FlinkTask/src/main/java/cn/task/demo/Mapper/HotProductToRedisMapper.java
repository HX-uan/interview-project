package cn.task.demo.Mapper;

import cn.task.demo.Entity.LogEntity;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommand;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisCommandDescription;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisMapper;

public class HotProductToRedisMapper implements RedisMapper<Tuple2<Integer, String>> {
    @Override
    public RedisCommandDescription getCommandDescription() {
        return new RedisCommandDescription(RedisCommand.SET, null);
    }

    @Override
    public String getKeyFromData(Tuple2<Integer, String> data) {
        System.out.println("key : " + data.f0.toString());
        return data.f0.toString();
    }

    @Override
    public String getValueFromData(Tuple2<Integer, String> data) {
        System.out.println("value : " + data.f1.toString());
        return data.f1;
    }
}
