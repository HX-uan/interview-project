package cn.task.demo.Enums;

public enum Color {

    Red("red"),
    Green("green"),
    White("white"),
    None("none");

    private String code;

    private Color(String code){
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static Color convert(String str){
        if (str == null){
            return None;
        }else if (str.equals("red")){
            return Red;
        }else if (str.equals("green")){
            return Green;
        }else if (str.equals("white")){
            return White;
        }
        return None;
    }
}
