package cn.task.demo.Entity;

import cn.task.demo.Enums.Age;
import cn.task.demo.Enums.Color;
import cn.task.demo.Enums.Country;
import cn.task.demo.Enums.Sex;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

public class ProductEntity implements PortraitEntity{

    private List<Age> ages;

    private List<Color> colors;

    private List<Country> countries;

    private List<Sex> sexes;

    public ProductEntity(){
        this.ages = new ArrayList<>();
        this.colors = new ArrayList<>();
        this.countries = new ArrayList<>();
        this.sexes = new ArrayList<>();
    }

    public List<Age> getAges() {
        return ages;
    }

    public Age getAge(Integer i) {
        if (i >= ages.size()){
            return Age.None;
        }
        return ages.get(i);
    }

    public void setAges(List<Age> ages) {
        this.ages = ages;
    }

    public void addAge(Age age) {
        this.ages.add(age);
    }

    public List<Color> getColors() {
        return colors;
    }

    public Color getColor(Integer i) {
        if (i >= colors.size()){
            return Color.None;
        }
        return colors.get(i);
    }

    public void setColors(List<Color> colors) {
        this.colors = colors;
    }

    public void addColor(Color color) {
        this.colors.add(color);
    }

    public List<Country> getCountries() {
        return countries;
    }

    public Country getCountry(Integer i) {
        if (i >= countries.size()){
            return Country.None;
        }
        return countries.get(i);
    }

    public void setCountries(List<Country> countries) {
        this.countries = countries;
    }

    public void addCountry(Country country) {
        this.countries.add(country);
    }

    public List<Sex> getSexes() {
        return sexes;
    }

    public Sex getSex(Integer i) {
        if (i >= sexes.size()){
            return Sex.None;
        }
        return sexes.get(i);
    }

    public void setSexes(List<Sex> sexes) {
        this.sexes = sexes;
    }

    public void addSex(Sex sex) {
        this.sexes.add(sex);
    }
}
