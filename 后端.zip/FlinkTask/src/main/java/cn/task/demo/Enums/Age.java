package cn.task.demo.Enums;

public enum Age {

    Young("0-29"),
    MiddleYoung("30-39"),
    Middle("40-49"),
    None("none");

    private String code;

    private Age(String code){
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static Age convert(String str){
        if (str == null){
            return None;
        }else if (str.equals("0-29")){
            return Young;
        }else if (str.equals("0-29")){
            return MiddleYoung;
        }else if (str.equals("0-29")){
            return Middle;
        }
        return None;
    }
}
