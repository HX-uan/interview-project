package cn.task.demo.Functions;

import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.functions.ProcessFunction;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.windows.GlobalWindow;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;

public class HotProductWindowFunction implements WindowFunction<Tuple3<String, Integer, Integer>, Tuple2<Integer, String>, Tuple, TimeWindow> {

    @Override
    public void apply(Tuple tuple, TimeWindow window, Iterable<Tuple3<String, Integer, Integer>> input, Collector<Tuple2<Integer, String>> out) throws Exception {

        List<Tuple3<String, Integer, Integer>> list = new ArrayList<>();
        input.forEach(single->{list.add(single);});
        list.sort(new Comparator<Tuple3<String, Integer, Integer>>(){
            @Override
            public int compare(Tuple3<String, Integer, Integer> o1, Tuple3<String, Integer, Integer> o2) {
                return o1.f1 - o2.f1;
            }
        });

        Integer length = list.size() > 10 ? 10 : list.size();
        for (int i = 1; i <= length; i++){
            System.out.println(Tuple2.of(i, list.get(list.size() - i).f0).toString()
                    + " score : " + list.get(list.size() - i).f1);
            System.out.println("-------------------------------------------");
            out.collect(Tuple2.of(i, list.get(list.size() - i).f0));
        }
    }
}
