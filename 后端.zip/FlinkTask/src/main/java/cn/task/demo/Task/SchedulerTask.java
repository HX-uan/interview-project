package cn.task.demo.Task;

import cn.task.demo.Clients.HBaseClient;
import cn.task.demo.Utils.ItemCoeffRecommend;
import cn.task.demo.Utils.ProductCoeffRecommend;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Timer;
import java.util.TimerTask;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SchedulerTask {

    private static ExecutorService executorService = Executors.newFixedThreadPool(10);

    public static void main(String[] args) {

        Timer timer = new Timer();
        timer.scheduleAtFixedRate(new TimerTask() {
            @Override
            public void run() {

                List<String> p_history = new ArrayList<>();

                try {
                    p_history = HBaseClient.getAllKey("p_history");
                } catch (IOException e) {
                    e.printStackTrace();
                }
                for (String id : p_history){
                    executorService.execute(new CoffTask(id, p_history));
                }
            }
        }, 0, 5 * 1000);
    }

    private static class CoffTask implements Runnable{

        private String id;
        private List<String> others;

        public CoffTask(String id, List<String> others) {
            this.id = id;
            this.others = others;
        }

        @Override
        public void run() {
            System.out.println("Start Task");
            ProductCoeffRecommend productCoeffRecommend = new ProductCoeffRecommend();
            ItemCoeffRecommend itemCoeffRecommend = new ItemCoeffRecommend();
            try {
                productCoeffRecommend.ProductCoeff(id, others);
                itemCoeffRecommend.ItemCoeff(id, others);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
}
