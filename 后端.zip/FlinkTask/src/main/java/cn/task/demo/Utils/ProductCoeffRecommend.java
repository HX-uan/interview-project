package cn.task.demo.Utils;

import cn.task.demo.Clients.HBaseClient;
import cn.task.demo.Entity.PortraitEntity;
import cn.task.demo.Entity.ProductEntity;
import cn.task.demo.Enums.*;
import org.apache.flink.api.java.tuple.Tuple2;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class ProductCoeffRecommend {

    private static final Integer sexLength = 2;
    private static final Integer ageLength = 3;
    private static final Integer colorLength = 3;
    private static final Integer countryLength = 3;

    private static final Double sexScore = 100.0;
    private static final Double ageScore = 10.0;
    private static final Double colorScore = 50.0;
    private static final Double countryScore = 5.0;

    private static final Double sexPercentage = 10.0;
    private static final Double agePercentage = 10.0;
    private static final Double colorPercentage = 10.0;
    private static final Double countryPercentage = 10.0;

    private static final Double allScore = sexScore * sexPercentage * sexLength +
                                            ageScore * agePercentage * ageLength +
                                            colorScore * colorPercentage * colorLength +
                                            countryScore * countryPercentage * countryLength;

    public void ProductCoeff(String id, List<String> others) throws Exception {
        List<Tuple2<String, Double>> list = new ArrayList<>();
        for (String other : others){
            if(id.equals(other)) continue;
            Double score = towProductCoeff(id, other);
            list.add(Tuple2.of(other, score));
        }
        saveToHBase(id, list);
    }

    private void saveToHBase(String id, List<Tuple2<String, Double>> list) throws Exception {
        for (Tuple2<String, Double> item : list){
            HBaseClient.putData("pp", id, "pid", item.f0, item.f1.toString());
        }
    }

    private Double towProductCoeff(String id, String other) throws IOException {
        PortraitEntity mineProductEntity = GenerateEntity.getPortraitEntityById(id, EntityType.Product);
        PortraitEntity otherProductEntity = GenerateEntity.getPortraitEntityById(other, EntityType.Product);
        Double score = 0.0;
        for (int i = 0; i < sexLength; i++){
            if (mineProductEntity.getSex(i) == otherProductEntity.getSex(i)
                    && mineProductEntity.getSex(i) != Sex.None){
                score += sexScore * sexPercentage;
            }
        }

        for (int i = 0; i < ageLength; i++){
            if (mineProductEntity.getAge(i) == otherProductEntity.getAge(i)
                    && mineProductEntity.getAge(i) != Age.None){
                score += ageScore * agePercentage;
            }
        }

        for (int i = 0; i < colorLength; i++){
            if (mineProductEntity.getColor(i) == otherProductEntity.getColor(i)
                    && mineProductEntity.getColor(i) != Color.None){
                score += colorScore * colorPercentage;
            }
        }

        for (int i = 0; i < countryLength; i++){
            if (mineProductEntity.getCountry(i) == otherProductEntity.getCountry(i)
                    && mineProductEntity.getCountry(i) != Country.None){
                score += countryScore * countryPercentage;
            }
        }
        score /= allScore;
        return score;
    }

}
