package cn.task.demo.Task;

import cn.task.demo.Functions.ToLogEntityMapFunction;
import cn.task.demo.Sink.LogToHBaseSink;
import cn.task.demo.Sink.LogToUHistoryHBaseSink;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.connectors.kafka.FlinkKafkaConsumer;

import java.util.Properties;

public class UHistoryTask {

    public static void main(String[] args) throws Exception {

        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        Properties properties = new Properties();
        properties.setProperty("bootstrap.servers", "localhost:9092");
        DataStream<String> stream = env.addSource(new FlinkKafkaConsumer<String>(
                "con", new SimpleStringSchema(), properties) );
        stream.map(new ToLogEntityMapFunction()).addSink(new LogToUHistoryHBaseSink());

        env.execute("UHistoryTask");
    }
}
