package cn.task.demo.Functions;

import cn.task.demo.Entity.LogEntity;
import org.apache.flink.api.java.tuple.Tuple;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.api.java.tuple.Tuple3;
import org.apache.flink.streaming.api.functions.windowing.WindowFunction;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;

public class WindowResultFunction
        implements WindowFunction<Long, Tuple3<String, Long, Long>, Tuple, TimeWindow> {
    @Override
    public void apply(Tuple key, TimeWindow window, Iterable<Long> aggregateResult, Collector<Tuple3<String, Long, Long>> collector) throws Exception {
        String uid = key.getField(0);
        Long count = aggregateResult.iterator().next();
        Tuple3<String, Long, Long> of = Tuple3.of(uid, count, window.getEnd());
        System.out.println(of.toString());
        collector.collect(of);
    }
}
