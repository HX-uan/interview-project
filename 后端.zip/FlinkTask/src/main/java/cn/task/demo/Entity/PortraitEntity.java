package cn.task.demo.Entity;

import cn.task.demo.Enums.Age;
import cn.task.demo.Enums.Color;
import cn.task.demo.Enums.Country;
import cn.task.demo.Enums.Sex;

import java.io.Serializable;
import java.util.List;

public interface PortraitEntity extends Serializable {
    List<Age> getAges();

    Age getAge(Integer i);

    void setAges(List<Age> ages);

    void addAge(Age age);

    List<Color> getColors();

    Color getColor(Integer i);

    void setColors(List<Color> colors);

    void addColor(Color color);

    List<Country> getCountries();

    Country getCountry(Integer i);

    void setCountries(List<Country> countries);

    void addCountry(Country country);

    List<Sex> getSexes();

    Sex getSex(Integer i);

    void setSexes(List<Sex> sexes);

    void addSex(Sex sex);
}
