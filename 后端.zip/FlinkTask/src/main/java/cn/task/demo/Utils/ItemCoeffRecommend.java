package cn.task.demo.Utils;

import cn.task.demo.Clients.HBaseClient;
import org.apache.flink.api.java.tuple.Tuple2;

import java.io.IOException;
import java.util.*;

public class ItemCoeffRecommend {


    private static final Double minUserSamplePenalized = 10.0;

    public void ItemCoeff(String id, List<String> others) throws Exception {
        List<Tuple2<String, Double>> list = new ArrayList<>();
        for (String other : others){
            if(id.equals(other)) continue;
            Double score = towItemCoeff(id, other);
            list.add(Tuple2.of(other, score));
        }
        saveToHBase(id, list);
    }

    private void saveToHBase(String id, List<Tuple2<String, Double>> list) throws Exception {
        for (Tuple2<String, Double> item : list){
            HBaseClient.putData("cf", id, "pid", item.f0, item.f1.toString());
        }
    }

    private Double towItemCoeff(String id, String other) throws IOException {

        Map<String, Double> mineP_history = ConvertUtils.listToMap(HBaseClient.getRow("p_history", id));
        Map<String, Double> otherP_history = ConvertUtils.listToMap(HBaseClient.getRow("p_history", other));

//---------------------------------------------
        Double avgMine = 0.0;
        Map<String, Double> mineUUMap = new HashMap<>();

        for (String key : mineP_history.keySet()){
            avgMine += mineP_history.get(key);
            int uLength = HBaseClient.getRow("u_history", key).size();
            int pLength = mineP_history.size();
            Double uu = Math.log(pLength / uLength);
            mineUUMap.put(key, uu);
        }
        // user average
        avgMine /= mineP_history.size();
        Double sqrtMine = 0.0;
        // u * (r_ui - u_u)^2
        for (String key : mineP_history.keySet()){
            sqrtMine += Math.pow(mineP_history.get(key) - avgMine, 2) * mineUUMap.get(key);
        }
        // sqrt
        sqrtMine = Math.sqrt(sqrtMine);
        if (Double.isNaN(sqrtMine) || sqrtMine == 0.0){
            sqrtMine = 1.0;
        }

//---------------------------------------------
        Double avgOther = 0.0;
        Map<String, Double> otherUUMap = new HashMap<>();
        for (String key : otherP_history.keySet()){
            avgOther += otherP_history.get(key);
            int uLength = HBaseClient.getRow("u_history", key).size();
            int pLength = otherP_history.size();
            Double uu = Math.log(pLength / uLength);
            otherUUMap.put(key, uu);
        }
        // user average
        avgOther /= otherP_history.size();
        Double sqrtOther = 0.0;
        for (String key : otherP_history.keySet()){
            sqrtMine += Math.pow(otherP_history.get(key) - avgMine, 2) * otherUUMap.get(key);
        }
        // sqrt
        sqrtOther = Math.sqrt(sqrtOther);
        if (Double.isNaN(sqrtOther) || sqrtOther == 0.0){
            sqrtOther = 1.0;
        }

//---------------------------------------------
        Double dot = 0.0;
        for (String key : mineP_history.keySet()){
            if (otherP_history.containsKey(key)){
                dot += mineUUMap.get(key) * otherUUMap.get(key)
                        * (mineP_history.get(key) - avgMine)
                        * (otherP_history.get(key) - avgOther);
            }
        }
        if (Double.isNaN(dot) || dot == 0.0){
            dot = 1.0;
        }
//---------------------------------------------
        Double adjustedSim = dot / (sqrtOther * sqrtMine);

//---------------------------------------------
        // min{mineP_history.size(), otherP_history.size(), minUserSamplePenalized} / minUserSamplePenalized
        Double w = Math.min(Math.min(mineP_history.size(), otherP_history.size()),
                minUserSamplePenalized)
                / minUserSamplePenalized;

        adjustedSim *= w;
        if (Double.isNaN(adjustedSim)){
            return 0.0;
        }
        return adjustedSim;
    }
}
