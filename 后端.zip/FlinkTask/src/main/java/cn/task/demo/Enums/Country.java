package cn.task.demo.Enums;

public enum Country {

    China("China"),
    USA("USA"),
    Germany("Germany"),
    None("none");

    private String code;

    private Country(String code){
        this.code = code;
    }

    public String getCode() {
        return code;
    }

    public static Country convert(String str){
        if (str == null){
            return None;
        }else if (str.equals("China")){
            return China;
        }else if (str.equals("USA")){
            return USA;
        }else if (str.equals("Germany")){
            return Germany;
        }
        return None;
    }
}
