package cn.task.demo.Sink;

import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;
import org.apache.flink.streaming.connectors.redis.RedisSink;
import org.apache.flink.streaming.connectors.redis.common.config.FlinkJedisConfigBase;
import org.apache.flink.streaming.connectors.redis.common.mapper.RedisMapper;

import java.util.List;
//
//public class HotProductToRedis extends RedisSink<Tuple2<String, Integer>> implements SinkFunction<List<Tuple2<String, Integer>>> {
//    /**
//     * Creates a new {@link RedisSink} that connects to the Redis server.
//     *
//     * @param flinkJedisConfigBase The configuration of {@link FlinkJedisConfigBase}
//     * @param redisSinkMapper      This is used to generate Redis command and key value from incoming elements.
//     */
//    public HotProductToRedis(FlinkJedisConfigBase flinkJedisConfigBase, RedisMapper<Tuple2<String, Integer>> redisSinkMapper) {
//        super(flinkJedisConfigBase, redisSinkMapper);
//    }
//
//    @Override
//    public void invoke(List<Tuple2<String, Integer>> value, Context context) throws Exception {
//        super.invoke(value, context);
//    }
//}
