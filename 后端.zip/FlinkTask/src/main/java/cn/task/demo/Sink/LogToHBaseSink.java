package cn.task.demo.Sink;

import cn.task.demo.Clients.HBaseClient;
import cn.task.demo.Entity.LogEntity;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.streaming.api.functions.sink.RichSinkFunction;
import org.apache.flink.streaming.api.functions.sink.SinkFunction;

public class LogToHBaseSink extends RichSinkFunction<LogEntity> {

    // 初始化方法
    public void open(Configuration parameters) throws Exception {

    }
    //Writes the given value to the sink. This function is called for every record.
    //每一个元素的插入，都会被调用一次invoke方法
    public void invoke(LogEntity value, Context context) throws Exception {
        System.out.println("存入数据 : " + value.toString());
        HBaseClient.putData("content", value.getTms(), "log", value.getUid(), value.toString());
    }

    public void close() throws Exception {

    }



}
