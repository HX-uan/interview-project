
1. content表 log记录
    1. log:uid -> log
    2. rowKey:tms
    
2. product表 产品画像表
    1. sex:[man | woman] -> [1 | 0]
    2. age:[10|20|30...] - > [1 | 0]
    3. color:[red | green |...] -> [1 | 0]
    4. country:[China | USA...] -> [1 | 0]
    5. style:[1 | 2 | 3 |...] -> [1 | 0]
    6. rowKey:pid
    
3. user表 用户画像表
   1. 与product表一样
   2. rowKey:uid
    
4. u_history表 用户与哪些产品交互 只记录次数
    1. pid:[pid] -> count
    2. rowKey:uid

5. p_history表 哪些用户与该产品交互 只记录次数
    1. uid:[uid] -> count
    2. rowKey:pid
       
6. pp表 基于产品画像的产品关联度
    1. pid:[pid] -> score
    2. rowKey:pid

7. cf表 基于协同过滤的产品关联度
    1. pid:[pid] -> score
    2. rowKey:uid?
    
8. u_interest表 用户兴趣表 记录Action分数
    1. pid:[pid] -> actionScore
    2. rowKey:uid

